package revik.com.energycostsavingestimator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyCostSavingEstimatorApplicationTests {

    @Test
    void contextLoads() {
    }

}
